import pygame
import pyratch
import threading
import copy
import time
import random
import sys
import math

def dist(x1, y1, x2, y2):
    return math.sqrt((x1-x2)**2+(y1-y2)**2)

pygame.init()
pygame.font.init()

sc = pygame.display.set_mode((800, 600))

wsize = 200

buildings = [[0]*wsize for i in range(wsize)]
world = [[0]*wsize for i in range(wsize)]

fl = open("map", "r")
rd = fl.read()
fl.close()

print("\rloading... 0%", end="")

for i in range(wsize-1, -1, -1):
    for j in range(wsize):
        if rd.split("\n")[j].split(" ")[i] != "":
            if rd.split("\n")[j].split(" ")[i] == "-":
                world[i][j] = -1
            elif rd.split("\n")[j].split(" ")[i] == "*":
                world[i][j] = 0
                buildings[i][j] = 1
            else:
                world[i][j] = int(rd.split("\n")[j].split(" ")[i])
    if i%4 == 0:
        print(f"\rloading... {(wsize-i)//2}%", end="")
print("\rloading... 100%!")

teamnum = int(input("team num? "))

teamc = [-1]*100
teamcs = [-1]*100
teamn = [0]*100
teamspawn = [-1]*100

rblank = pygame.surface.Surface((30, 30))
rblank.fill((245, 245, 245))

rblanks = pygame.surface.Surface((2, 2))
rblanks.fill((245, 245, 245))

rsea = pygame.surface.Surface((30, 30))
rsea.fill((135, 206, 250))

rseas = pygame.surface.Surface((2, 2))
rseas.fill((135, 206, 250))

teamcl = [0]*100

allai = []

# TODO SPLIT: AI

class AI:
    x, y = 0, 0
    def __init__(self, team):
        self.id = len(allai)
        allai.append(self)
        self.team = team
        self.x, self.y = teamspawn[team]
        self.lstdir = -1
        self.targx, self.targy = -1, -1
        self.new = 0

    def move(self):
        dire = random.randint(0, 3)
        if dire == 0:
            self.x += 1
        elif dire == 1:
            self.x -= 1
        elif dire == 2:
            self.y += 1
        elif dire == 3:
            self.y -= 1

# todo SPLIT: init

for i in range(1, teamnum+1):
    teamn.append(int(input(f"how many player in team {i}: ")))
    teamspawn[i] = (random.randint(5, wsize-5), random.randint(5, wsize-5))
    world[teamspawn[i][0]][teamspawn[i][1]] = i
    rect_r = pygame.surface.Surface((30, 30))
    tc = (random.randint(50, 150), random.randint(50, 150), random.randint(50, 150))
    rect_r.fill(tc)
    teamc[i] = rect_r
    rect_r = pygame.surface.Surface((2, 2))
    rect_r.fill(tc)
    teamcs[i] = rect_r
    teamcl[i] = tc
    for j in range(teamn[-1]):
        AI(i)

sn = pygame.surface.Surface((15, 15))
sn.fill((255, 255, 255))

snai = pygame.surface.Surface((15, 15))
sn.fill((0, 0, 0))

vx, vy = teamspawn[1]
dirx, diry = 0, 0
mode = 0



tick = 0
wworld = [[0]*wsize for i in range(wsize)]
running = True

scores = [0]*100

# todo SPLIT: finding and filling

def dfs2(nx, ny):
    stk = [(nx, ny)]
    while len(stk) > 0:
        ax, ay = stk.pop()
        if world[ax][ay] == 0:
            wworld[ax][ay] = -1
            if ax-1 >= 0 and wworld[ax-1][ay] == 0:
                stk.append((ax-1, ay))
            if ax + 1 < wsize and wworld[ax+1][ay] == 0:
                stk.append((ax + 1, ay))
            if ay - 1 > 0 and wworld[ax][ay-1] == 0:
                stk.append((ax, ay - 1))
            if ay + 1 < wsize and wworld[ax][ay+1] == 0:
                stk.append((ax, ay+1))

def dfs1(nx, ny, nm):
    stk = [(nx, ny)]
    while len(stk) > 0:
        ax, ay = stk.pop()
        if wworld[ax][ay] != -1 and world[ax][ay] in [nm, 0]:
            world[ax][ay] = nm
            wworld[ax][ay] = -1
            if ax - 1 >= 0 and wworld[ax - 1][ay] != -1:
                stk.append((ax - 1, ay))
            if ax + 1 < wsize and wworld[ax + 1][ay] != -1:
                stk.append((ax + 1, ay))
            if ay - 1 > 0 and wworld[ax][ay - 1] != -1:
                stk.append((ax, ay - 1))
            if ay + 1 < wsize and wworld[ax][ay + 1] != -1:
                stk.append((ax, ay + 1))

def dfs0(nx, ny, nm):
    stk = [(nx, ny)]
    while len(stk) > 0:
        ax, ay = stk.pop()
        if wworld[ax][ay] == 0 and world[ax][ay] == world[nx][ny]:
            wworld[ax][ay] = 1
            if ax - 1 >= 0:
                stk.append((ax - 1, ay))
            else:
                return
            if ax + 1 < wsize:
                stk.append((ax + 1, ay))
            else:
                return
            if ay - 1 > 0:
                stk.append((ax, ay - 1))
            else:
                return
            if ay + 1 < wsize:
                stk.append((ax, ay + 1))
            else:
                return
        elif world[ax][ay] == nm:
            continue
        elif world[ax][ay] not in [world[nx][ny], nm]:
            return
    stk = [(nx, ny)]
    while len(stk) > 0:
        ax, ay = stk.pop()
        if wworld[ax][ay] != -1 and world[ax][ay] in [nm, world[nx][ny]]:
            wworld[ax][ay] = -1
            world[ax][ay] = nm
            if ax - 1 >= 0 and wworld[ax - 1][ay] != -1:
                stk.append((ax - 1, ay))
            if ax + 1 < wsize and wworld[ax + 1][ay] != -1:
                stk.append((ax + 1, ay))
            if ay - 1 > 0 and wworld[ax][ay - 1] != -1:
                stk.append((ax, ay - 1))
            if ay + 1 < wsize and wworld[ax][ay + 1] != -1:
                stk.append((ax, ay + 1))

def uupdate():
    global world, wworld, scores
    while running:
        if tick % 20 == 10:
            scores = [0] * 100
            for i in range(wsize):
                for j in range(wsize):
                    if world[i][j] > 0:
                        scores[world[i][j]] += 1
                        if buildings[i][j] == 1:
                            scores[world[i][j]] += 19
            wworld = [[0]*wsize for i in range(wsize)]
            for i in range(0, wsize):
                if wworld[i][0] == 0:
                    dfs2(i, 0)
                if wworld[0][i] == 0:
                    dfs2(0, i)
                if wworld[i][wsize-1] == 0:
                    dfs2(i, wsize-1)
                if wworld[wsize-1][i] == 0:
                    dfs2(wsize-1, i)
            for i in range(1, wsize - 1):
                for j in range(1, wsize - 1):
                    if wworld[i][j] == 0 and world[i][j] == 0 and (-1 == world[i - 1][j] or -1 == world[i + 1][j] or -1 == world[i][j - 1] or -1 == world[i][j + 1]):
                        dfs2(i, j)
            for i in range(1, wsize-1):
                for j in range(1, wsize-1):
                    if wworld[i][j] == 0 and world[i][j] > 0 and (0 < world[i - 1][j] != world[i][j] or 0 < world[i + 1][j] != world[i][j] or 0 < world[i][j - 1] != world[i][j] or 0 < world[i][j + 1] != world[i][j]):
                        cl = -1
                        if 0 < world[i-1][j] != world[i][j]:
                            cl = world[i-1][j]
                        if 0 < world[i + 1][j] != world[i][j]:
                            cl = world[i + 1][j]
                        if 0 < world[i][j - 1] != world[i][j]:
                            cl = world[i][j - 1]
                        if 0 < world[i][j + 1] != world[i][j]:
                            cl = world[i][j + 1]
                        dfs0(i, j, cl)
                    if wworld[i][j] == 0 and world[i][j] > 0:
                        dfs1(i, j, world[i][j])

# todo SPLIT: main loop

ticktime = 0

st = threading.Thread(target=uupdate)
st.start()

while True:
    ticktime = time.time()
    sc.fill((255, 255, 255))
    x, y = 0, 0
    for i in range(max(0, vx-13), min(wsize, max(0, vx-13)+26)):
        for j in range(max(0, vy-13), min(wsize, max(0, vy-13)+26)):
            if world[i][j] > 0:
                sc.blit(teamc[world[i][j]], (x, y))
            elif world[i][j] == 0:
                sc.blit(rblank, (x, y))
            elif world[i][j] == -1:
                sc.blit(rsea, (x, y))
            if buildings[i][j] == 1:
                pygame.draw.circle(sc, (0, 0, 0), (x+15, y+15), 10)
            if i == vx and j == vy:
                sc.blit(sn, (x+7, y+7))
            for k in allai:
                if i == k.x and j == k.y:
                    sc.blit(snai, (x + 7, y + 7))
            y += 31
        y = 0
        x += 31
    x, y = 10, 10
    for i in range(1, 1+teamnum):
        sc.blit(pygame.font.Font(None, 24).render(f"team {i}: {scores[i]}", True, teamcl[i]), (x, y))
        y += 30
    x, y = 700, 500
    for i in range(50):
        for j in range(50):
            if world[wsize//50*i][wsize//50*j] > 0:
                sc.blit(teamcs[world[wsize//50*i][wsize//50*j]], (x, y))
            elif world[wsize//50*i][wsize//50*j] == -1:
                sc.blit(rseas, (x, y))
            else:
                sc.blit(rblank, (x, y))
            y += 2
        y = 450
        x += 2
    if world[vx][vy] != -1:
        world[vx][vy] = 1
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        diry = -1
        dirx = 0
    if keys[pygame.K_s]:
        diry = 1
        dirx = 0
    if keys[pygame.K_a]:
        dirx = -1
        diry = 0
    if keys[pygame.K_d]:
        dirx = 1
        diry = 0
    if tick%10 == 0:
        vx += dirx
        vy += diry
        if not(0 <= vx < wsize) or not(0 <= vy < wsize):
            vx -= dirx
            vy -= diry
        for i in allai:
            i.move()
            if i.x < 0:
                i.x += 1
            elif i.x >= wsize:
                i.x -= 1
            if i.y < 0:
                i.y += 1
            elif i.y >= wsize:
                i.y -= 1
            if world[i.x][i.y] != -1:
                world[i.x][i.y] = i.team
    for ev in pygame.event.get():
        if ev.type == pygame.QUIT:
            running = False
            pygame.quit()
            exit(0)
    # while time.time() < ticktime+0.01:
        # time.sleep(0.001)
    pygame.display.flip()
    tick += 1
